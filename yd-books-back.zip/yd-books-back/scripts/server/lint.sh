# nodejs代码的语法检测工具
echo "lint🍌"
cross-env NODE_ENV=lint gulp